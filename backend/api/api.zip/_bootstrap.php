<?php
// /api/_bootstrap.php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
start_session_safe();

/* Siempre JSON */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

/* Auth obligatoria para API consola */
require_console_auth(['admin','staff']);

/* Utilidades */
function only_methods(array $allowed): void {
    $m = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if (!in_array($m, $allowed, true)) json_exit(['ok'=>false,'error'=>'METHOD_NOT_ALLOWED'], 405);
}
function need_csrf_for_write(): void {
    $m = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($m !== 'GET' && !csrf_ok_from_header_or_post()) json_exit(['ok'=>false,'error'=>'CSRF'], 403);
}
function table_exists(mysqli $c, string $t): bool {
    $q=$c->query("SHOW TABLES LIKE '".$c->real_escape_string($t)."'"); return (bool)$q->num_rows;
}
function columns_of(mysqli $c, string $t): array {
    $r=[]; $q=$c->query("SHOW COLUMNS FROM `{$t}`"); while($row=$q->fetch_assoc()) $r[]=$row['Field']; return $r;
}
function str_norm(string $s): string {
    $s = mb_strtolower(trim($s), 'UTF-8');
    $s = iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s);
    $s = preg_replace('/[^a-z0-9]+/',' ',$s);
    $s = preg_replace('/\s+/',' ',$s);
    return trim($s);
}
