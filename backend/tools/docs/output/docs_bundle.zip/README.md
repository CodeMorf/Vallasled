# Documentación Console

- Base: `/console/`
- Generado: `2025-10-13T15:09:01-04:00`
- Política: la vista no incluye JS/CSS; `_layout.php` inyecta por módulo; `sidebar.php` es HTML.

