## Módulos

| Módulo | Vista | AJAX dir | CSS glob | JS glob |
|---|---|---|---|---|
| `facturacion` | `/console/facturacion/index.php` | `/console/facturacion/ajax/` | `/console/asset/css/facturacion/*.css` | `/console/asset/js/facturacion/*.js` |
| `vallas` | `/console/vallas/index.php` | `/console/vallas/ajax/` | `/console/asset/css/vallas/*.css` | `/console/asset/js/vallas/*.js` |
| `portal` | `/console/portal/index.php` | `/console/portal/ajax/` | `/console/asset/css/portal/*.css` | `/console/asset/js/portal/*.js` |
| `reservas` | `/console/reservas/index.php` | `/console/reservas/ajax/` | `/console/asset/css/reservas/*.css` | `/console/asset/js/reservas/*.js` |
