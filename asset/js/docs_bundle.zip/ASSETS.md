## Assets

### facturacion

**CSS**:
- `/console/asset/css/facturacion/lista.css` · sha256:c1d587c2dbe767e424fc362bc315a6fa1bf2ddb8ab4033a464aeb426dfd00529
- `/console/asset/css/facturacion/bancos.css` · sha256:1255d71369c7f7d34cf9c16b2dbded7cf3f7e4366df1297cbe5eb365b43df2f9
- `/console/asset/css/facturacion/crear.css` · sha256:815be80e5f04edfcccfa9e083a07b0fe45b068c5d77ace610b9f636ef6671d18
- `/console/asset/css/facturacion/dashboard.css` · sha256:80a33b90a1c13324a4043acf90ed75c595dfe4498b1dbdcbcb70a7f33566a7d1
- `/console/asset/css/facturacion/facturas.css` · sha256:5dc9660f3f532f31e9b1c3c1d0effe08c0a737b82a4024424c80a211fe383947

**JS**:
- `/console/asset/js/facturacion/lista.js` · sha256:f4ab0f549432c8bcf92dca15d34d4e0116e0f71f0a4c84333ee10c0c1a4e97ad
- `/console/asset/js/facturacion/bancos.js` · sha256:519abadce9c02ea24172fbf70ca849323bc07f483a3971aefbbcacd9eafa82ab
- `/console/asset/js/facturacion/crear.js` · sha256:b8bbacd76a092445acf86c45c411846e65d427052e07ca435b459516a5f09500
- `/console/asset/js/facturacion/facturas_crear.js` · sha256:823d66eb570c8f05c3b60bbcf776492604df175c88ff2459d018c6f6ccc927e2
- `/console/asset/js/facturacion/dashboard.js` · sha256:d9c2d0dddd0acc373e7cdd58e1351eca5175ff69ff483ca154680f62456072a6

### vallas

**CSS**:

**JS**:

### portal

**CSS**:

**JS**:

### reservas

**CSS**:
- `/console/asset/css/reservas/reservas.css` · sha256:cdb4515cd05bbb16b83592183c1ff3ae804b8357769cd83ffab1c7fd3615e5af

**JS**:
- `/console/asset/js/reservas/reservas.js` · sha256:efc0cd6b8aeab3a6375c6c92f6399ec017b094f05131ddd1ade1604b02d8ab7f

